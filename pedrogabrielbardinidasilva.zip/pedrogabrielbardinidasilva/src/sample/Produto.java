package sample;

public class Produto {
    public class Produto {
        private String nome;

        public String






        etNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public double getPreco() {
            return preco;
        }

        public void setPreco(double preco) {
            this.preco = preco;
        }

        private double preco;
    }
    @Override
    public String toString(){
        return "produto:" + nome
                + "preço:" + preco;
    }
}
