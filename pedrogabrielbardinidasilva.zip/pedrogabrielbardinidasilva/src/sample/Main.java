package sample;

public class Main {
    public static void main(String[] args){
        Produto produto1 = new Produto();
        produto1.setNome("livro");
        produto1.setPreco("50 reais");

        System.out.println(produto1);

    }
}